<template>
  <router-view />
</template>

<style></style>
