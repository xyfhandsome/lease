// ? 全局不动配置项 只做导出不做修改
// * 高德地图 key
export const AMAP_MAP_KEY = "5e8245ac445d7cd6d98b178ed42b5700";
// 高德地图 安全密匙
export const AMAP_MAP_SECRET_KEY = "2f047c7b569d899dbd1ab8ccd11c22ed";

export const AMAP_MAP_SERVICE_HOST = "http://www.gitlbo.top:8181/_AMapService";
