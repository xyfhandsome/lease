// 全局样式
import "./index.less";
// tailwindcss
import "./tailwind.css";
// Toast
import "vant/es/toast/style";

// Dialog
import "vant/es/dialog/style";

// Notify
import "vant/es/notify/style";

// ImagePreview
import "vant/es/image-preview/style";
