import SwitchDark from './src/SwitchDark.vue'

export { SwitchDark }
