import SvgIcon from './src/SvgIcon.vue'
export { SvgIcon }
