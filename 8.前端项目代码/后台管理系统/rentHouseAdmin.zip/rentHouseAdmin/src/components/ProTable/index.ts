import ProTable from './src/ProTable.vue'
export { ProTable }
