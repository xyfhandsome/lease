import IconifyIcon from './src/IconifyIcon'
export { IconifyIcon }
