<template>
  <el-card>home_page</el-card>
</template>
<script setup lang="ts">
// import { ref, reactive, toRefs, computed, watch } from 'vue'
// import { useRoute, useRouter } from 'vue-router'
</script>

<style lang="scss" scoped></style>
